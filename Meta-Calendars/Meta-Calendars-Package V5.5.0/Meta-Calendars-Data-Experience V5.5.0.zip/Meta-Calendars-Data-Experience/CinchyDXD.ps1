param (
  # Common
  [Parameter(Position = 0, Mandatory = $False)] [String] $global:Action

  # Shared for pull, push
  , [Parameter(Mandatory = $False)] [String] $s
  , [Parameter(Mandatory = $False)] [String] $u
  , [Parameter(Mandatory = $False)] [String] $p
  , [Parameter(Mandatory = $False)] [Int]    $Start = 1
  , [Parameter(Mandatory = $False)] [Int]    $End = 10
  
  # Required for pull
  , [Parameter(Mandatory = $False)] [String] $g
  , [Parameter(Mandatory = $False)] [String] $o
  , [Parameter(Mandatory = $False)] [String] $v
  
  # Optional for pull
  , [Parameter(Mandatory = $False)] [Switch] $x = $False # Keep output folder temp directory
  , [Parameter(Mandatory = $False)] [Switch] $w = $False # Write files to Cinchy
  
  # Optional for push
  , [Parameter(Mandatory = $False)] [String] $d
  , [Parameter(Mandatory = $False)] [String] $ps
  , [Parameter(Mandatory = $False)] [Switch] $e = $False # Pause on errors
  , [Parameter(Mandatory = $False)] [Switch] $m = $False # Ignore Model errors
  , [Parameter(Mandatory = $False)] [Switch] $z = $False # Connections output
  , [Parameter(Mandatory = $False)] [Switch] $y = $False # Force push over existing
)

#region Set Global Parameters

# DXDF Common
$DxdfGuid        = "ada2e71c-a3c7-4a3b-8d84-8afb5258bfb8"
$ApiClientID     = "cinchy_dxd"
$ApiClientSecret = "c0cfde958fec4c7598ac2e1df9a1ba15"
$CliModel        = "Cinchy"
$DxdCliVersion   = "1.0.0"
$DxdVersion      = "1.5.0"

# Environment
$KeepFiles           = if ($w) { $true } else { $false }
$KeepTemp            = if ($x) { $true } else { $false }
$ForceInstall        = if ($y) { $true } else { $false }
$global:PauseOnError = if ($e) { $true } else { $false }
$global:PauseOnModel = if ($m) { $false } else { $true }
$ConnectionsOutput   = if ($z) { $true } else { $false }
$Location            = Split-Path $MyInvocation.MyCommand.Path

# Data Experience Definition
$DxdGuid         = $g
$ReleaseVersion  = $v

# Cinchy Server
$CinchyServer    = $s
$CinchyUser      = $u
$CinchyPswd      = $p

# DXD Environment
$ConnectionsTempPath = $d
$CinchyDeployPath    = $o
$CinchyPsPath        = $ps

#endregion Set Global Parameters

#region Help Templates
$Version = @"

 CinchyDXD $($DxdVersion)
 Copyright (C) $(Get-Date -Format yyyy) CinchyDXD

"@
$Help = @"
 export   Exports a Data Experience from a Cinchy source environment.

 install  Installs a Data Experience in a Cinchy target environment.

 help     Displays this help text. To display help for an action, pass only that action

 version  Displays version information.

"@
$ExportCommandHelp = @"

 export                         Required. Exports a Data Experience from a Cinchy source environment.

"@
$InstallCommandHelp = @"

 install                        Required. Installs a Data Experience in a Cinchy target environment.

"@
$CommonHelp = @"
 -s     (Cinchy Server)         Required. The full path to the Cinchy server without the protocol (e.g.
                                          cinchy.com/Cinchy).

 -u     (Username)              Required. The user id for accessing Cinchy.

 -p     (Password)              Required. The clear text or encrypted password of the specified user.

"@
$ExportHelp = @"
 -g     (DXD Guid)              Required. The Data Experience Definition Guid.

 -v     (DXD Version)           Required. The Data Experience Definition Version.

 -o     (DXD Output Directory)  Required. The path to a directory where CinchyDXD will create
                                          the Data Experience release export.

 -w     (Write Binary Files     Optional. Flag indicating that CinchyDXD should save the release files
         to Cinchy)                       into Cinchy.

 -x     (CinchyDXD Temp         Optional. Flag indicating that CinchyDXD should not clean up the output
         Directory)                       temp directory.

 -start (Start Step)            Optional. The Export Step to start from.

 -end   (End Step)              Optional. The Export Step to end on.

"@
$InstallHelp = @"
 -d     (Connections Temp       Optional. The path to a directory that Connections can use for storing
         Directory)                       temporary files to support the sync.

 -e     (Pause On Errors)       Optional. Prompt to continue on Connection and Model Loader errors.

 -m     (Ignore Model Errors)   Optional. Do not stop on ModelLoader errors.

 -z     (Display Sync Output)   Optional. Displays the Connections output on completion.

 -ps    (Post Install Scripts)  Optional. The path to a directory with one or more CQL scripts to
                                          be executed once the install is complete.

 -start (Start Step)            Optional. The Install Step to start from.

 -end   (End Step)              Optional. The Install Step to end on.

 -y     (Force Install)         Optional. Force the install if the release already exists in the target.

"@
#endregion Help Templates

Write-Host $Version

#region Validate parameters
switch ($global:Action) {
  'export' {
    if (Test-Path $(Join-Path $Location "scripts/ps/pull.ps1") -PathType Leaf) {
      if ( !$s, !$u, !$p, !$g, !$v, !$o -contains $True ) {
        Write-Host " ERROR(s)`n"
        $global:Action = 'export-help'
      }
      if (!$s) { Write-Host " Required option -s (Cinchy Server) is missing." }
      if (!$u) { Write-Host " Required option -u (Username) is missing." }
      if (!$p) { Write-Host " Required option -p (Password) is missing." }
      if (!$g) { Write-Host " Required option -g (DXD Guid) is missing." }
      if (!$v) { Write-Host " Required option -v (DXD Version) is missing." }
      if (!$o) { Write-Host " Required option -o (DXD Output Directory) is missing." }
    }
    else {
      Write-Host " ERROR(s)`n"
      Write-Host " Export must be run from within the CinchyDXD directory.`n"
      exit 2
    }
  }
  'install' {
    if ((Test-Path $(Join-Path $Location "dxd.ini") -PathType Leaf) -and (Test-Path $(Join-Path $Location "scripts/push.ps1") -PathType Leaf)) {
      if ( !$s, !$u, !$p -contains $True ) {
        Write-Host " ERROR(s)`n"
        $global:Action = 'install-help'
      }
      if (!$s) { Write-Host " Required option -s (Cinchy Server) is missing." }
      if (!$u) { Write-Host " Required option -u (Username) is missing." }
      if (!$p) { Write-Host " Required option -p (Password) is missing." }
    }
    else {
      Write-Host " ERROR(s)`n"
      Write-Host " Install must be run from within a release directory.`n"
      exit 2
    }
  }
  'version' {}
  'help' {}
  Default {
    Write-Host " ERROR(s)`n"
    Write-Host " `'$global:Action' is an unknown action. Valid actions are:`n"
    $global:Action = 'help'
  }
}
#endregion Validate parameters

# Perform the requested Action
switch ($global:Action) {
  'export' {
    # Log setup
    $LogPath = $(Join-Path $CinchyDeployPath "logs")
    New-Item -Path $LogPath -ItemType Directory -Force | Out-Null

    . $(Join-Path $Location "scripts/ps/pull.ps1")
  }
  'install' {
    # Log setup
    $LogPath = $(Join-Path $Location "logs")
    New-Item -Path $LogPath -ItemType Directory -Force | Out-Null

    . $(Join-Path $Location "scripts/push.ps1")
  }
  'help' {
    Write-Host $Help
    exit 0
  }
  'export-help' {
    Write-Host $ExportCommandHelp
    Write-Host $CommonHelp
    Write-Host $ExportHelp
    exit 2
  }
  'install-help' {
    Write-Host $InstallCommandHelp
    Write-Host $CommonHelp
    Write-Host $InstallHelp
    exit 2
  }
}
