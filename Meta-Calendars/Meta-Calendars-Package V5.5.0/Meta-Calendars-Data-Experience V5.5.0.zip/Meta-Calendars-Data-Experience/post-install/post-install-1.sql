DECLARE @CinchyURL VARCHAR(100)
DECLARE @CalendarURL VARCHAR(100)


/*                   Input the below              */ 

SET @CinchyURL = '<Cinchy URL>'
SET @CalendarURL = '<Calendar URL>'


/*                    End of Input                 */


SELECT 
[Path] =
CASE WHEN LEN(@CinchyURL) - LEN(REPLACE(@CinchyURL, '/', '')) > 2 THEN
SUBSTRING(
			SUBSTRING(@CinchyURL,CHARINDEX('//',@CinchyURL)+2,LEN(@CinchyURL)),
			CHARINDEX('/',
						SUBSTRING(@CinchyURL,
        				 			CHARINDEX('//',@CinchyURL)+2,
                 		 			LEN(@CinchyURL)
                  					)
        			  ),
			LEN(@CinchyURL))
ELSE ''
END
INTO #path


/* Retrieving Cinchy Id of the Editor Applet */
SELECT 
ca.[Cinchy Id]
INTO #editorID
FROM [Cinchy].[Applets] ca
WHERE ca.[Deleted] IS NULL
AND ca.[Full Name] = 'Cinchy Calendar.Cinchy Calendar'




UPDATE a
SET
a.[Application URL] = @CalendarURL
FROM [Cinchy].[Applets] a
LEFT JOIN #editorID e ON 1=1
WHERE a.[Deleted] IS NULL
AND a.[Full Name] = 'Cinchy Calendar.Cinchy Calendar'
AND a.[Application Url] != @CalendarURL




UPDATE tc
SET 
tc.[Calculated Column Expression] = CASE WHEN tc.[Full Name] = 'Cinchy Calendar.Calendars.Actions' THEN 
                                                REPLACE(REPLACE(
                                                  tc.[Calculated Column Expression],'/dxdev/cinchy',p.[Path]),'appId=7',CONCAT('appId=',CAST(e.[Cinchy Id] AS VARCHAR(100))))
                                         WHEN tc.[Full Name] = 'Cinchy Calendar.Calendars.Table URL' AND LOWER(@CinchyURL) NOT LIKE '%/cinchy%' THEN   
                                                REPLACE(
                                                tc.[Calculated Column Expression],'../Cinchy','..')
                                    END
FROM [Cinchy].[Table Columns] tc
LEFT JOIN #editorID e ON 1=1
LEFT JOIN #path p ON 1=1
WHERE
  tc.[Deleted] IS NULL
  AND tc.[Full Name] IN ('Cinchy Calendar.Calendars.Actions','Cinchy Calendar.Calendars.Table URL')
  AND tc.[Calculated Column Expression] != CASE WHEN tc.[Full Name] = 'Cinchy Calendar.Calendars.Actions' THEN 
                                                    REPLACE(REPLACE(
                                                      tc.[Calculated Column Expression],'/dxdev/cinchy',p.[Path]),'appId=7',CONCAT('appId=',CAST(e.[Cinchy Id] AS VARCHAR(100))))
                                                WHEN tc.[Full Name] = 'Cinchy Calendar.Calendars.Table URL' AND LOWER(@CinchyURL) NOT LIKE '%/cinchy%' THEN   
                                                    REPLACE(
                                                    tc.[Calculated Column Expression],'../Cinchy','..')
                                            END

UPDATE s
SET 
s.[Json] =
  REPLACE(REPLACE(REPLACE(
    s.[Json],'/dxdev/cinchy',p.[Path]),'appId=7',CONCAT('appId=',CAST(e.[Cinchy Id] AS VARCHAR(100)))),'../Cinchy',CASE WHEN LOWER(@CinchyURL) NOT LIKE '%/cinchy%' THEN '..' ELSE '../Cinchy' END)
FROM [Cinchy].[Tables] s
LEFT JOIN #editorID e ON 1=1
LEFT JOIN #path p ON 1=1
WHERE
  s.[Deleted] IS NULL
  AND s.[Full Name] = 'Cinchy Calendar.Calendars'
  AND s.[Json] !=   REPLACE(REPLACE(REPLACE(
    s.[Json],'/dxdev/cinchy',p.[Path]),'appId=7',CONCAT('appId=',CAST(e.[Cinchy Id] AS VARCHAR(100)))),'../Cinchy',CASE WHEN LOWER(@CinchyURL) NOT LIKE '%/cinchy%' THEN '..' ELSE '../Cinchy' END)

