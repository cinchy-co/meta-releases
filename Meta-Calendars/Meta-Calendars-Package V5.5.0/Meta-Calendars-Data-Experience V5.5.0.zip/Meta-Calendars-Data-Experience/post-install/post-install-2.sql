
UPDATE r1
SET 
r1.[Title] = r2.[Title]
FROM [Cinchy Calendar].[Calendars] r1
INNER JOIN [Cinchy Calendar].[Calendars] r2 ON r2.[Deleted] IS NULL AND r2.[Calendar ID] = r1.[Calendar ID]
WHERE r1.[Deleted] IS NULL

