# ReadMe

This ReadMe contains general information on the components of the Meta-Forms experience. The components should be deployed in the order specified below. Given your Cinchy version environment, you should only install either (3) or (4).


## Components
1) Meta-Forms-App-Experience-V5.2.0.zip                     : Angular build files for Meta-Forms UI
2) Meta-Examples V1.0.0.zip                                 : DXD package containing model of an example form.
3) Meta-Forms-Data-Experience V5.2.0 (Cinchy v4).zip        : DXD package for Cinchy v4 target environment. Contains the tables and queries that support the Meta-Forms UI
4) Meta-Forms-Data-Experience V5.2.0.zip                    : DXD package for Cinchy v5 target environment. Contains the tables and queries that support the Meta-Forms UI


