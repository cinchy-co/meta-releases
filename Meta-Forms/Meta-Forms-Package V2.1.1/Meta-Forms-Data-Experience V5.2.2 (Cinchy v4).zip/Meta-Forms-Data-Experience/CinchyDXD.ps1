param (
  # Common
  [Parameter(Position = 0, Mandatory = $False)] [String] $global:Action

  # Shared for pull, push
  , [Parameter(Mandatory = $False)] [Switch] $h = $False
  , [Parameter(Mandatory = $False)] [String] $s
  , [Parameter(Mandatory = $False)] [String] $sso
  , [Parameter(Mandatory = $False)] [String] $u
  , [Parameter(Mandatory = $False)] [String] $p
  , [Parameter(Mandatory = $False)] [String] $c
  , [Parameter(Mandatory = $False)] [String] $d
  , [Parameter(Mandatory = $False)] [Int]    $Start = 1
  , [Parameter(Mandatory = $False)] [Int]    $End = 10

  # Required for pull
  , [Parameter(Mandatory = $False)] [String] $g
  , [Parameter(Mandatory = $False)] [String] $o
  , [Parameter(Mandatory = $False)] [String] $v
  
  # Optional for pull
  , [Parameter(Mandatory = $False)] [Switch] $x = $False # Keep output folder temp directory
  , [Parameter(Mandatory = $False)] [Switch] $e = $False # Use EXE CLI instead of DLL
  , [Parameter(Mandatory = $False)] [Switch] $w = $False # Write files to Cinchy
    
  # Optional for push
  , [Parameter(Mandatory = $False)] [String] $ps
  , [Parameter(Mandatory = $False)] [Switch] $y = $False # Force push over existing
  , [Parameter(Mandatory = $False)] [Switch] $z = $False # Write the CLI statements to the log

  # Required for encrypt
  , [Parameter(Mandatory = $False)] [String] $t
)

#region Set Global Parameters

# DXDF Common
$DxdfGuid             = "ada2e71c-a3c7-4a3b-8d84-8afb5258bfb8"
$ApiClientID          = "cinchy_dxd"
$ApiClientSecret      = "c0cfde958fec4c7598ac2e1df9a1ba15"
$CliModel             = "Cinchy"
$DxdCliVersion        = "1.0.0"
$DxdVersion           = "1.4.0"

# Environment
$KeepFiles            = if ($w) { $True } else { $False }
$KeepTemp             = if ($x) { $True } else { $False }
$ForceInstall         = if ($y) { $True } else { $False }
$LogSyncdata          = if ($z) { $True } else { $False }
$Location             = Split-Path $MyInvocation.MyCommand.Path

# Data Experience Definition
$DxdGuid              = $g
$ReleaseVersion       = $v

# Cinchy Server
$CinchyServer         = $s.TrimEnd("/")
$CinchyServerSSO      = if ($sso) { $sso } else { "$CinchyServer`sso" }
$CinchyServerProtocol = if ($h) { "https" } else { "http" }
$CinchyUser           = $u
try {
  $CinchyPswd = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($p))
}
catch {
  $CinchyPswd = $p
}

# Cinchy CLI
$CinchyCLIPath       = $c
$CinchyCLITempPath   = $d
$CinchyConnections   = $true
$CinchyCLIPrefix     = "Cinchy.Connections.CLI"

if (!$(Test-Path $(Join-Path $CinchyCLIPath "$CinchyCLIPrefix.dll") -PathType Leaf)) {
  $CinchyCLIPrefix   = "Cinchy.CLI"
  $CinchyConnections = $false
}
if ($c -ne "") {
  $CinchyCLIBinary   = if ($e) { "`"$(Join-Path $CinchyCLIPath "$CinchyCLIPrefix.exe")`"" } else { "dotnet `"$(Join-Path $CinchyCLIPath "$CinchyCLIPrefix.dll")`"" }
  $CinchyCLIVersion  = (Get-Command $(Join-Path $CinchyCLIPath "$CinchyCLIPrefix.dll")).Version.Major
}

# Cinchy DXD Pull
$CinchyDeployPath     = $o

# Cinchy DXD Push
$CinchyPsPath         = $ps

#endregion Set Global Parameters

#region Help Templates
$Version = @"

 CinchyDXD $($DxdVersion)
 Copyright (C) $(Get-Date -Format yyyy) CinchyDXD

"@
$Help = @"
 export   Exports a Data Experience from a Cinchy source environment.

 install  Installs a Data Experience in a Cinchy target environment.

 encrypt  Generate an encrypted string.

 help     Displays this help text. To display help for an action, pass only that action

 version  Displays version information.

"@
$ExportCommandHelp = @"

 export                         Required. Exports a Data Experience from a Cinchy source environment.

"@
$InstallCommandHelp = @"

 install                        Required. Installs a Data Experience in a Cinchy target environment.

"@
$EncryptCommandHelp = @"

 encrypt                        Required. Generate an encrypted string.

"@
$CommonHelp = @"
 -h     (https)                 Optional. Flag indicating connections to Cinchy should be over https.

 -s     (Cinchy Server)         Required. The full path to the Cinchy server without the protocol (e.g.
                                          cinchy.com/Cinchy).

 -sso   (CinchySSO Server)      Optional. The full path the the CinchySSO server without the protocol (e.g.
                                          cinchy.com/CinchySSO). This is only required if your CinchySSO server
                                          is different than /CinchySSO.

 -u     (Username)              Required. The user id for accessing Cinchy.

 -p     (Password)              Required. The clear text or encrypted password of the specified user.

 -c     (CinchyCLI Directory)   Required. The path to the Cinchy CLI.

 -d     (CinchyCLI Temp         Required. The path to a directory that the CLI can use for storing
         Directory)                       temporary files to support the sync (e.g. partitioned data).

 -e     (CinchyCLI EXE)         Optional. Flag to use Cinchy.CLI.exe. Cinchy.CLI.dll is the default.

"@
$ExportHelp = @"
 -g     (DXD Guid)              Required. The Data Experience Definition Guid.

 -v     (DXD Version)           Required. The Data Experience Definition Version.

 -o     (DXD Output Directory)  Required. The path to a directory where CinchyDXD will create
                                          the Data Experience release export.

 -w     (Write Binary Files     Optional. Flag indicating that CinchyDXD should save the release files
         to Cinchy)                       into Cinchy.

 -x     (CinchyDXD Temp         Optional. Flag indicating that CinchyDXD should not clean up the output
         Directory)                       temp directory.

 -start (Start Step)            Optional. The Export Step to start from.

 -end   (End Step)              Optional. The Export Step to end on.

"@
$InstallHelp = @"
 -ps    (Post Install Scripts)  Optional. The path to a directory with one or more CQL scripts to
                                          be executed once the install is complete.

 -start (Start Step)            Optional. The Install Step to start from.

 -end   (End Step)              Optional. The Install Step to end on.

 -y     (Force Install)         Optional. Force the install if the release already exists in the target.

 -z     (Log syncdata)          Optional. Write the CLI syncdata commands to the log.

"@
$EncryptHelp = @"
 -t     (String to Encrypt)     Required. The full text to encrypt.

"@
#endregion Help Templates

Write-Host $Version

#region Validate parameters
switch ($global:Action) {
  'export' {
    if (Test-Path $(Join-Path $Location "scripts/ps/pull.ps1") -PathType Leaf) {
      if ( !$s, !$u, !$p, !$c, !$d, !$g, !$v, !$o -contains $True ) {
        Write-Host " ERROR(s)`n"
        $global:Action = 'export-help'
      }
      if (!$s) { Write-Host " Required option -s (Cinchy Server) is missing." }
      if (!$u) { Write-Host " Required option -u (Username) is missing." }
      if (!$p) { Write-Host " Required option -p (Password) is missing." }
      if (!$c) { Write-Host " Required option -c (CinchyCLI Directory) is missing." }
      if (!$d) { Write-Host " Required option -d (CinchyCLI Temp Directory) is missing." }
      if (!$g) { Write-Host " Required option -g (DXD Guid) is missing." }
      if (!$v) { Write-Host " Required option -v (DXD Version) is missing." }
      if (!$o) { Write-Host " Required option -o (DXD Output Directory) is missing." }
    }
    else {
      Write-Host " ERROR(s)`n"
      Write-Host " Export must be run from within the CinchyDXD directory.`n"
      exit 2
    }
  }
  'install' {
    if ((Test-Path $(Join-Path $Location "dxd.ini") -PathType Leaf) -and (Test-Path $(Join-Path $Location "scripts/push.ps1") -PathType Leaf)) {
      if ( !$s, !$u, !$p, !$c, !$d -contains $True ) {
        Write-Host " ERROR(s)`n"
        $global:Action = 'install-help'
      }
      if (!$s) { Write-Host " Required option -s (Cinchy Server) is missing." }
      if (!$u) { Write-Host " Required option -u (Username) is missing." }
      if (!$p) { Write-Host " Required option -p (Password) is missing." }
      if (!$c) { Write-Host " Required option -c (CinchyCLI Directory) is missing." }
      if (!$d) { Write-Host " Required option -d (CinchyCLI Temp Directory) is missing." }
    }
    else {
      Write-Host " ERROR(s)`n"
      Write-Host " Install must be run from within a release directory.`n"
      exit 2
    }
  }
  'encrypt' {
    if ( !$t -contains $True ) {
      Write-Host " ERROR(s)`n"
      $global:Action = 'encrypt-help'
    }
    if (!$t) { Write-Host " Required option -t (String to Encrypt) is missing." }
  }
  'version' {}
  'help' {}
  Default {
    Write-Host " ERROR(s)`n"
    Write-Host " `'$global:Action' is an unknown action. Valid actions are:`n"
    $global:Action = 'help'
  }
}
#endregion Validate parameters

# Perform the requested Action
switch ($global:Action) {
  'export' {
    # Log setup
    $LogPath = $(Join-Path $CinchyDeployPath "logs")
    New-Item -Path $LogPath -ItemType Directory -Force | Out-Null

   . $(Join-Path $Location "scripts/ps/pull.ps1")
  }
  'install' {
    # Log setup
    $LogPath = $(Join-Path $Location "logs")
    New-Item -Path $LogPath -ItemType Directory -Force | Out-Null

   . $(Join-Path $Location "scripts/push.ps1")
  }
  'encrypt' {
    $GetBytes = [System.Text.Encoding]::Unicode.GetBytes($t)
    $EncryptedString = [Convert]::ToBase64String($GetBytes)
    Write-Host $EncryptedString
  }
  'help' {
    Write-Host $Help
    exit 0
  }
  'export-help' {
    Write-Host $ExportCommandHelp
    Write-Host $CommonHelp
    Write-Host $ExportHelp
    exit 2
  }
  'install-help' {
    Write-Host $InstallCommandHelp
    Write-Host $CommonHelp
    Write-Host $InstallHelp
    exit 2
  }
  'encrypt-help' {
    Write-Host $EncryptCommandHelp
    Write-Host $EncryptHelp
    exit 2
  }
}
