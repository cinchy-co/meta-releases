# Cinchy DXD common functions
$ProgressPreference = 'SilentlyContinue'
$MyInvocation.ScriptName
$LogFile = Split-Path $MyInvocation.PSCommandPath -Leaf
$LogFile = "$($LogFile -replace '.ps1', '') $(get-date -format `"yyyyMMdd_hhmmsstt`").log"

function WriteMessage($Message, $LogOnly = $false) {
  $Message = "$('[{0:MM/dd/yyyy} {0:HH:mm:ss}]' -f (Get-Date)) | $Message"
  if (!$LogOnly) { Write-Host $Message }
  Add-Content $(Join-Path $LogPath $LogFile) -value $Message -ErrorAction Ignore
}

function GetCinchyVersion() {
  $Header = @{
    Authorization = "Bearer $BearerToken"
  }
  try {
    $Endpoint = "$CinchyServerProtocol`://$CinchyServer/Healthcheck"
    $Result = Invoke-WebRequest -Uri $Endpoint -UseBasicParsing -Method GET -Headers $Header -ErrorAction Stop | ConvertFrom-Json
    return $Result.version
  }
  catch {
    WriteMessage "ERROR - Could not retrieve Healthcheck from Cinchy"
    exit 1
  }
}

function GetBearerToken() {
  $Header = @{
    Content_Type = "application/x-www-form-urlencoded"
  }
  $Body = @{
    username      = $CinchyUser
    password      = $CinchyPswd
    client_id     = $ApiClientID
    client_secret = $ApiClientSecret
    grant_type    = 'password'
    scope         = 'js_api'
  }
  $Endpoint = "$CinchyServerProtocol`://$CinchyServerSSO/identity/connect/token"
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $Result = Invoke-WebRequest -Uri $Endpoint -UseBasicParsing -Method POST -Body $Body -Headers $Header -ErrorAction Stop
    $Token = $Result | ConvertFrom-JSON | Select-Object -ExpandProperty access_token
    return $Token
  }
  catch {
    WriteMessage "ERROR - Could not get the Bearer Token"
    exit 1
  }
}

function Encrypt($Text) {
  $Text = $Text.Replace('$','`$')
  if ($CinchyServerProtocol -eq 'https') { $Flag = ' -h' }
  if ($CinchyConnections) {
    $CliCommand = $CliConnectionsEncrypt -f $CinchyCLIBinary, $Flag, $CinchyServer, $CinchyUser, $CinchyPswd, $Text
  } else {
    $CliCommand = $CliEncrypt -f $CinchyCLIBinary, $Text
  }
  $Result = Invoke-Expression $CliCommand
  return $Result
}

function ExecuteQuery($Query, $QueryType, $ResultFormat, $CompressJSON = $true) {
  $Header = @{
    Authorization = "Bearer $BearerToken"
  }
  $Body = @{
    Resultformat = $ResultFormat
    Type         = $QueryType
    Query        = $Query
    CompressJSON = $CompressJSON
  }
  try {
    $Endpoint = "$CinchyServerProtocol`://$CinchyServer/API/ExecuteCQL"
    $Result = Invoke-WebRequest -Uri $Endpoint -UseBasicParsing -Method POST -Body $Body -Headers $Header -ErrorAction Stop
    return $Result
  }
  catch {
    switch ($QueryType) {
      'QUERY' {
        WriteMessage "ERROR - Could not retrieve $ResultFormat data from Cinchy"
      }
      'NONQUERY' {
        WriteMessage "ERROR - Could not insert data into Cinchy"
      }
    }
    exit 1
  }
}

function GetDXD($DxdGuid) {
  $DxdMetadata = Get-Content -Path $(Join-Path $Location "scripts/sql/cinchy/Data Experience Definitions.sql")
  $Result = ExecuteQuery ($DxdMetadata -f $DxdGuid, "") 'QUERY' 'JSON' $false | ConvertFrom-Json -ErrorAction Stop
  $Result.Name
}

function ExecuteCLI($SyncConfig, $Parameters, $FileParameters) {
  if ($CinchyServerProtocol -eq 'https') { $Flag = ' -h' }
  WriteMessage ("-" * 80)
  WriteMessage "- Executing CLI : $SyncConfig"
  if ($CinchyConnections) {
    if ($Parameters -eq "") {
      $Parameters = " --file $FileParameters"
    } else {
      $Parameters = " -v $Parameters --file $FileParameters"
    }
    $CliCommand = $CliConnectionsSyncdata -f $CinchyCLIBinary, $Flag, $CinchyServer, $CinchyUser, $CinchyPswdEncrypted, $SyncConfig, $CinchyCLITempPath, $Parameters
  } else {
    if ($CinchyCLIVersion -gt 3) { $QuietMode = ' -q' }
    if ($Parameters -eq "") {
      $Parameters = " -v $FileParameters"
    } else {
      $Parameters = " -v $Parameters $FileParameters"
    }
    $CliCommand = $CliSyncdata -f $CinchyCLIBinary, $Flag, $CinchyServer, $CinchyUser, $CinchyPswdEncrypted, $CliModel, $SyncConfig, $CinchyCLITempPath, $QuietMode, $Parameters
  }
  if ($LogSyncdata) { WriteMessage "- SyncData Command:`n`n$CliCommand" }

  Write-Output "`n"
  Invoke-Expression $CliCommand
  Write-Output "`n"

  switch ($LASTEXITCODE) {
    0 { WriteMessage "  ...Completed without errors" }
    1 { WriteMessage "  ...Execution failed" }
    2 { WriteMessage "  ...Completed with validation errors" }
  }
  if (!$LogSyncdata -and $LASTEXITCODE -ne 0) { WriteMessage "- SyncData Command:`n`n$CliCommand`n" }
}

function GenerateModel($Guid, $ReleaseVersion, $OutFile) {
  $Header = @{
    Authorization = "Bearer $BearerToken"
  }
  try {
    $Endpoint = "$CinchyServerProtocol`://$CinchyServer/API/CreateDXVersion?guid=$Guid&modelVersion=$ReleaseVersion"
    Invoke-WebRequest -Uri $Endpoint -UseBasicParsing -Method GET -Headers $Header -PassThru -OutFile $OutFile -ErrorAction Stop
  }
  catch {
    continue
  }
}

function LoadModel($Model) {
  $Model = Join-Path $Location "model/$Model"
  $FileName = Split-Path $Model -leaf
  $Boundary = "----" + [guid]::NewGuid().ToString()

  $FileBin = [System.IO.File]::ReadAllBytes($Model)
  $Enc = [System.Text.Encoding]::GetEncoding("iso-8859-1")

  $Endpoint = "$CinchyServerProtocol`://$CinchyServer/Apps/ModelLoader"
  $Body = $ModelLoaderTemplate -f $Boundary, $FileName, $Enc.GetString($FileBin)
  $ContentType = "multipart/form-data; boundary=$Boundary"
  $Header = @{
    "Authorization" = "Bearer $BearerToken"
    "cache-control" = "no-cache"
  }

  try {
    $Result = Invoke-RestMethod -Uri $Endpoint -UseBasicParsing -Method POST -Body $Body -ContentType $ContentType -Headers $Header -ErrorAction Stop
    return $Result
  }
  catch {
    if ($CinchyVersParts[0] -ge 5) {
      WriteMessage "ERROR - Model Failed to Load. Check $CinchyServerProtocol`://$CinchyServer/Cinchy/Models if the record already exists for this DXD version."
    } else {
      WriteMessage "ERROR - Model Failed to Load. See $CinchyServerProtocol`://$CinchyServer/Elmah for details, or check $CinchyServerProtocol`://$CinchyServer/Cinchy/Models if the record already exists for this DXD version."
    }
    exit 1
  }
}

function GenerateCSV($Query) {
  $SqlTemplate = Get-Content -Path $(Join-Path $Location "scripts/sql/cinchy/$Query")
  if ($Query -eq 'Data Experience Releases.sql') {
    $Result = ExecuteQuery ($SqlTemplate -f $DxdGuid, $ReleaseVersion) 'QUERY' 'CSV'
  } else {
    $Result = ExecuteQuery ($SqlTemplate -f $DxdGuid, $ForXmlValue) 'QUERY' 'CSV'
  }
  return $Result.Content
}

function GenerateRefDataCSV($Query) {
  $Result = ExecuteQuery $Query 'QUERY' 'CSV' $false
  return $Result.Content
}

function GenerateRefDataXml($RefDataId, $Name) {
  $RefDataTableMetadata = Get-Content -Path $(Join-Path $Location "scripts/sql/refdata/Table Metadata.sql")
  $Result = ExecuteQuery ($RefDataTableMetadata -f $RefDataId) 'QUERY' 'JSON'
  try {
    $Recordset = $Result.content | ConvertFrom-Json -ErrorAction Stop
    if (($Recordset.data.Count) -ne 1) {
      WriteMessage "ERROR - $($Recordset.data.Count) records retrieved, expecting only one record"
      exit 1
    }
    else {
      $Domain = $Recordset.data[0][0]
      $TableName = $Recordset.data[0][1]
      $Ordinal = $Recordset.data[0][2]
      $TargetFilter = $Recordset.data[0][3]
      $NewRecords = $Recordset.data[0][4]
      $ChangedRecords = $Recordset.data[0][5]
      $DroppedRecords = $Recordset.data[0][6]
      $ExpirationTimestamp = $Recordset.data[0][7]
    }
  }
  catch {
    WriteMessage ("ERROR - Could not retrieve table configuration from Cinchy`n" + $_.Exception.Message) "Y"
    exit 1
  }

  $RefDataColumnMetadata = Get-Content -Path $(Join-Path $Location "scripts/sql/refdata/Table Columns Metadata.sql")
  $Result = ExecuteQuery ($RefDataColumnMetadata -f $RefDataId) 'QUERY' 'JSON'
  try {
    $Recordset = $Result.content | ConvertFrom-Json -ErrorAction Stop
    if (($Recordset.data.Count) -eq 0) {
      WriteMessage "ERROR - $($Recordset.data.Count) records retrieved, expecting more than one record"
      exit 1
    }
    else {
      $Columns =
      foreach ($Record in $Recordset.data) {
        $CliXmlColumnsTemplate -f $Record[1], $Record[2]
      }
      $ColumnMappings =
      foreach ($Record in $Recordset.data) {
        if ($Record[5]) {
          $CliXmlColumnMappingLinkTemplate -f $Record[3], $Record[4], $Record[5]
        }
        else {
          $CliXmlColumnMappingTemplate -f $Record[3], $Record[4]
        }
      }
      $Columns = $Columns | Out-String
      $ColumnMappings = $ColumnMappings | Out-String
    }
  }
  catch {
    WriteMessage ("ERROR - Could not retrieve column metadata from Cinchy`n" + $_.Exception.Message) "Y"
    exit 1
  }

  #SyncKeys
  $RefDataSyncKeys = Get-Content -Path $(Join-Path $Location "scripts/sql/refdata/Table SyncKeys.sql")
  $Result = ExecuteQuery ($RefDataSyncKeys -f $RefDataId) 'QUERY' 'JSON'
  try {
    $Recordset = $Result.content | ConvertFrom-Json -ErrorAction Stop
    if (($Recordset.data.Count) -eq 0) {
      WriteMessage "ERROR - $($Recordset.data.Count) records retrieved, expecting more than one record"
      exit 1
    }
    else {
      $SyncKeys = foreach ($Record in $Recordset.data) {
        $CliXmlSyncKeyTemplate -f $Record
      }
      $SyncKeys = $SyncKeys | Out-String
    }
  }
  catch {
    WriteMessage ("ERROR - Could not retrieve sync keys from Cinchy`n" + $_.Exception.Message) "Y"
    exit 1
  }

  if ($ExpirationTimestamp -ne '' -and $DroppedRecords -eq 'EXPIRE') {
    $ExpirationTimestamp = " expirationTimestampField=`"$ExpirationTimestamp`""
  }
  else {
    $ExpirationTimestamp = ''
  }
  $CliXmlTemp = $CliXmlTemplate -f $Name, $Columns, $Domain, $TableName, $ColumnMappings, $TargetFilter, $SyncKeys, $NewRecords, $ChangedRecords, $DroppedRecords, $ExpirationTimestamp
  $CliXmlTemp = $CliXmlTemp.replace( '&', '&amp;' )
  $CliXmlTemp = $CliXmlTemp.replace( '&amp;amp;', '&amp;')
  $CliXmlTemp = $CliXmlTemp.replace( '&amp;lt;', '&lt;')
  $CliXmlTemp = $CliXmlTemp.replace( '&amp;gt;', '&gt;')
  $CliXmlTemp = $CliXmlTemp.replace( '&amp;quot;', '&quot;')
  $CliXmlTemp = $CliXmlTemp.replace( '&amp;apos;', '&apos;')

  return $CliXmlTemp
}

function LoadDXDATA($Table) {
  $CliName = $FileTemplateDXDATA -f 'Cinchy', $Table
  $CsvFile = $FileTemplateDXDATA -f $DxdName, $Table
  ExecuteCLI $CliName "dxdGuid:`"$DxdGuid`"" "filePath:`"$(Join-Path $Location "csv/$CsvFile.csv")`""
}

function LoadREFDATA($CsvFile) {
  $CliName = $CsvFile -Replace '.csv', ''
  ExecuteCLI $CliName "" "filePath:`"$(Join-Path $Location "csv/$CsvFile")`""
}

function Base64Encode($File) {
  $BinaryFile = [System.IO.File]::ReadAllBytes("$File")
  $Base64File = [System.Convert]::ToBase64String($BinaryFile)
  return $Base64File
}

function WriteArtifact($Type, $File) {
  $global:ArtifactCount ++
  $FileName = Split-Path $File -leaf
  Compress-Archive -Path "$File" -DestinationPath "$DeployPath\temp\$FileName.zip" -CompressionLevel "Optimal" -Force
  if ($KeepFiles -eq $True) {
    $Query = $InsertDataExperienceReleaseArtifacts -f $Type, $ArtifactCount, "$FileName.zip", $(Base64Encode $File), "$($DxdName -replace '&', '&amp;' -replace '&amp;amp;', '&amp;') V$ReleaseVersion"
  }
  else {
    $Query = $InsertDataExperienceReleaseArtifacts -f $Type, $ArtifactCount, "$FileName", $Null, "$($DxdName -replace '&', '&amp;' -replace '&amp;amp;', '&amp;') V$ReleaseVersion"
  }
  ExecuteQuery $Query 'NONQUERY' 'JSON' | Out-Null
  WriteMessage "- Saved Artifact : $FileName"
}

# Global executions
$BearerToken = GetBearerToken
$CinchyPswdEncrypted = Encrypt $CinchyPswd
