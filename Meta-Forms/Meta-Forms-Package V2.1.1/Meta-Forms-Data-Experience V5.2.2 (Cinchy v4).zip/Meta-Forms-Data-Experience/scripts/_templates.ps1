# Model Template
$ModelLoaderTemplate = @'
--{0}
Content-Disposition: form-data; name="xmlFile"; filename="{1}"
Content-Type: text/xml

{2}
--{0}
Content-Disposition: form-data; name="dropColumns"

true
--{0}
Content-Disposition: form-data; name="updateColumns"

true
--{0}
Content-Disposition: form-data; name="renameTablesAndUpdateDomains"

true
--{0}
Content-Disposition: form-data; name="recalulateCalculatedColumns"

true
--{0}--

'@

# CLI Templates
$CliXmlTemplate = @'
<?xml version="1.0" encoding="utf-16"?>
<BatchDataSyncConfig name="{0}" version="1.0.0" xmlns="http://www.cinchy.co">
  <Parameters>
    <Parameter name="filePath" />
  </Parameters>
  <DelimitedDataSource delimiter="," textQualifier="&quot;" headerRowsToIgnore="1" path="@filePath" encoding="UTF8">
    <Schema>
{1}    </Schema>
  </DelimitedDataSource>
  <CinchyTableTarget model="" domain="{2}" table="{3}" suppressDuplicateErrors="false">
    <ColumnMappings>
{4}    </ColumnMappings>
    <Filter>{5}</Filter>
    <SyncKey>
{6}    </SyncKey>
    <NewRecordBehaviour type="{7}" />
    <ChangedRecordBehaviour type="{8}" />
    <DroppedRecordBehaviour type="{9}"{10} />
  </CinchyTableTarget>
</BatchDataSyncConfig>
'@
$CliXmlColumnsTemplate            = '      <Column name="{0}" dataType="{1}" />'
$CliXmlColumnMappingTemplate      = '      <ColumnMapping sourceColumn="{0}" targetColumn="{1}" />'
$CliXmlColumnMappingLinkTemplate  = '      <ColumnMapping sourceColumn="{0}" targetColumn="{1}" linkColumn="{2}" />'
$CliXmlSyncKeyTemplate            = '      <SyncKeyColumnReference name="{0}" />'
$CliSyncdata                      = '{0} syncdata{1} -s "{2}" -u "{3}" -p "{4}" -m "{5}" -f "{6}" -d "{7}"{8}{9}'
$CliConnectionsSyncdata           = '. {0} syncdata{1} -s "{2}" -u "{3}" -p "{4}" -f "{5}" -d "{6}"{7}'
$CliEncrypt                       = '{0} encrypt -t "{1}"'
$CliConnectionsEncrypt            = '. {0} encrypt{1} -s "{2}" -u "{3}" -p "{4}" -t "{5}"'

# File Templates
$FileTemplateMODEL                = 'DXDF - {0} - MODEL - Model'
$FileTemplateREFDATA              = 'DXDF - {0} - REFDATA - {1} - {2}'
$FileTemplateDXDF                 = 'DXDF - {0} - DXDF - {1}'
$FileTemplateDXDATA               = 'DXDF - {0} - DXDATA - {1}'

# Select Templates
$RefDataQueryTemplate             = 'SELECT{0} FROM {1}{2}'
$DxrQueryTemplate                 = "SELECT [Data Experience], [Release Version] FROM [Cinchy].[Cinchy].[Data Experience Releases] WHERE [Deleted] IS NULL AND ISNULL([Data Experience].[Sync GUID],[Data Experience].[Guid]) = '{0}' AND [Release Version] = '{1}'"

# Insert/Update Templates
$InsertDataSyncConfigurations         = @"
IF (
  SELECT 1
  FROM [Cinchy].[Cinchy].[Data Sync Configurations]
  WHERE
    [Deleted] IS NULL
    AND [Sync GUID] = '{1}'
  ) = 1
BEGIN
  UPDATE dsc
  SET
    dsc.[Config XML] = CAST('{0}' AS NVARCHAR(MAX))
  FROM [Cinchy].[Cinchy].[Data Sync Configurations] dsc
  WHERE
    dsc.[Deleted] IS NULL
    AND dsc.[Config XML] != '{0}'
    AND dsc.[Sync GUID] = '{1}'
END
ELSE
BEGIN
  INSERT INTO [Cinchy].[Cinchy].[Data Sync Configurations] ([Config XML], [Sync GUID], [Admin Groups]) VALUES ('{0}','{1}',RESOLVELINK('All Users','Name'))
END
"@
$InsertDataExperienceReleases         = "INSERT INTO [Cinchy].[Cinchy].[Data Experience Releases] ([Release Version], [Data Experience]) VALUES ('{0}',RESOLVELINK('{1}','Guid'))"
$UpdateDataExperienceReleases         = "UPDATE [Cinchy].[Cinchy].[Data Experience Releases] SET [Release Binary] = CAST('{0}' AS VARBINARY) WHERE [Deleted] IS NULL AND [Data Experience] = '{1}'"
$InsertDataExperienceReleaseArtifacts = "INSERT INTO [Cinchy].[Cinchy].[Data Experience Release Artifacts] ([Type], [Ordinal], [File Name], [File Binary], [Data Experience Release]) VALUES ('{0}',{1},'{2}','{3}',RESOLVELINK('{4}','Release Name'))"

$InitializeViews                      = @"
DELETE v 
FROM [Cinchy].[Cinchy].[Views] v
WHERE
  v.[Deleted] IS NULL
  AND (
    v.[Name] = 'All Data'
    OR v.[Table].[Deleted] IS NOT NULL
  )

DELETE vc 
FROM [Cinchy].[Cinchy].[View Columns] vc
WHERE
  vc.[Deleted] IS NULL
  AND (
    vc.[View].[Deleted] IS NOT NULL
    OR vc.[Column].[Deleted] IS NOT NULL
  )

DELETE vclg
FROM [Cinchy].[Cinchy].[View Column Link Graph] vclg
WHERE
  vclg.[Deleted] IS NULL
  AND (
    vclg.[View Column].[Deleted] IS NOT NULL
    OR vclg.[Link Column].[Deleted] IS NOT NULL
  )
"@

$CleanUpCLIs                          = @"
DELETE dsc
FROM [Cinchy].[Cinchy].[Data Sync Configurations] dsc
WHERE
  dsc.[Deleted] IS NULL
  AND dsc.[Sync Guid] LIKE '{0}_1.0.0_DXDF%'
"@