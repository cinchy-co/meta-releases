# ReadMe

This ReadMe contains general information on the components of the Meta-Forms experience. The components can be deployed in the order specified below.


## Components
1. Meta-Forms-App-Experience v5.5.1.zip                     : Angular build files for Meta-Forms UI
2. Meta-Forms-Data-Experience V5.5.1.zip                    : DXD package containing the tables and queries that support the Meta-Forms UI


