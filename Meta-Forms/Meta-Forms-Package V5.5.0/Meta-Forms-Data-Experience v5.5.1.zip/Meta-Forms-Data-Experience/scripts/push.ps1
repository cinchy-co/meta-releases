. $(Join-Path $Location "scripts/_templates.ps1")
. $(Join-Path $Location "scripts/_functions.ps1")

#region Process dxd.ini
Get-Content $(Join-Path $Location "dxd.ini") | ForEach-Object `
  -Begin { 
  $DxdIni = @{}
} `
  -Process {
  $Vars = [regex]::split($_, '=')
  if (($Vars[0].CompareTo("") -ne 0) -and ($Vars[0].StartsWith("[") -ne $True)) {
    $DxdIni.Add($Vars[0], $Vars[1])
  }
}

$DxdCinchyVers = $DxdIni.CinchyVers
$DxdCinchyVersParts = $DxdCinchyVers -split ("\.", 4)
$CinchyVers = GetCinchyVersion
$CinchyVersParts = $CinchyVers -split ("\.", 4)
$DxdGuid = $DxdIni.DxdGuid
$DxdName = $DxdIni.DxdName
$DxdVers = $DxdIni.DxdVers

#endregion Process dxd.ini

WriteMessage "Installing the $DxdName Data Experience into $CinchyServer"

#region First check that the release doesn't already exist
$Query = $DxrQueryTemplate -f $DxdGuid, $DxdVers
$Result = ExecuteQuery $Query 'QUERY' 'JSON'
try {
  $Recordset = $Result.content | ConvertFrom-Json -ErrorAction Stop
  if ($Recordset.data.Count -eq 1 -and !$ForceInstall) {
    WriteMessage "ERROR - Release $DxdName V$DxdVers already exists in $CinchyServer`n"
    exit 1
  }
  elseif ($Recordset.data.Count -eq 1 -and $ForceInstall) {
    WriteMessage "WARN - Release $DxdName V$DxdVers already exists in $CinchyServer"
    WriteMessage "     - Will attempt to overwrite"
  }
}
catch {
  WriteMessage "ERROR - Could not retrieve Data Experience Release data from Cinchy`n"
  exit 1
}
#endregion First check that the release doesn't already exist

#region Compare Cinchy Versions
if ($DxdCinchyVers -ne $CinchyVers) {
  WriteMessage "WARN - Export Cinchy version is $DxdCinchyVers. $CinchyServer version is $CinchyVers"
}
#endregion Compare Cinchy Versions

$Steps = @()

if ($Start -gt $End) {
  "End value can not be less than Start value"
  break
}
elseif (($Start -le 0) -or ($End -le 0)) {
  "Start and/or End value must be greater than 0"
  break
}
else {
  for ($i = $Start; $i -le $End; $i++) {   
    $Steps = $Steps + $i
  }
}
$i = 0

switch ($Steps) {
  # Insert Data Sync Configurations CLI
  1 {
    WriteMessage ("-" * 100)
    WriteMessage "Step: [$($Steps[$i])] - Loading the Cinchy Table CLIs"

    WriteMessage "- Initialize Views"
    ExecuteQuery $InitializeViews 'NONQUERY' 'JSON' | Out-Null

    $XmlList = Get-ChildItem -Path $(Join-Path $Location "cli") -Name
    foreach ($File in $XmlList) {
      $DSCFileContents = Get-Content -Path $(Join-Path $Location "cli/$File") -Raw | Out-String
      $DSCFileContents = $DSCFileContents -replace "'", "''"
      $SyncGuid = "$DxdfGuid`_$DxdCliVersion`_$($File -replace '.xml', '')"
      $Query = $InsertDataSyncConfigurations -f $DSCFileContents, $SyncGuid
      WriteMessage "- Loading CLI : $($File -replace '.xml', '')"
      ExecuteQuery $Query 'NONQUERY' 'JSON' | Out-Null
    }

    WriteMessage "Step: [$($Steps[$i++])] - Complete"
  }
  # Load DXDATA and REFDATA Data Sync Configurations
  2 {
    WriteMessage ("-" * 100)
    WriteMessage "Step: [$($Steps[$i])] - Loading the $DxdName Data Experience and Reference Data CLIs"

    # Load System Colours and Domains first
    LoadDXDATA 'Domains'
    LoadDXDATA 'System Colours'
    LoadDXDATA 'Groups'

    $CliName = $FileTemplateDXDATA -f 'Cinchy', 'Data Sync Configurations'
    $CsvFiles = Get-ChildItem -Path $(Join-Path $Location "csv") -Name -Filter '*DXDATA - Data Sync Configurations.csv'
    foreach ($CsvFile in $CsvFiles) {
      ExecuteConnection $CliName @{"dxdGuid"="$($DxdGuid)_DXDATA"} @{"filePath"="$(Join-Path $Location "csv/$($CsvFile)")"}
    }
    $CsvFiles = Get-ChildItem -Path $(Join-Path $Location "csv") -Name -Filter '*REFDATA - 0 - Data Sync Configurations.csv'
    foreach ($CsvFile in $CsvFiles) {
      ExecuteConnection $CliName @{"dxdGuid"="$($DxdGuid)_REFDATA"} @{"filePath"="$(Join-Path $Location "csv/$($CsvFile)")"}
    }

    WriteMessage "Step: [$($Steps[$i++])] - Complete"
  }
  # Load MODEL
  3 {
    WriteMessage ("-" * 100)
    WriteMessage "Step: [$($Steps[$i])] - Installing the $DxdName Data Experience Model"

    # Load Model(s)
    $XmlFiles = Get-ChildItem -Path $(Join-Path $Location "model") -Name | Sort-Object
    foreach ($XmlFile in $XmlFiles) {
      WriteMessage "- Loading Model : $('{0,-53}' -f $XmlFile -replace '.xml', '')"
      $ModelRows = Get-Content -Path $(Join-Path $Location "model/$XmlFile") -TotalCount 2 | Measure-Object -Line
      if ($ModelRows.Lines -gt 1) {
        $Result = LoadModel $XmlFile
        if ($Result -eq "Success") {
          WriteMessage "- Loading Model : $('{0,-53}' -f $XmlFile -replace '.xml', '') : $($Result.ToUpper())"
        }
      }
    }

    WriteMessage "Step: [$($Steps[$i++])] - Complete"
  }
  # Load DXDATA (in order)
  4 {
    WriteMessage ("-" * 100)
    WriteMessage "Step: [$($Steps[$i])] - Installing the $DxdName Data Experience Metadata"

    LoadDXDATA 'Table Access Control'
    LoadDXDATA 'Saved Queries'
    LoadDXDATA 'User Defined Functions'
    LoadDXDATA 'Views'
    LoadDXDATA 'View Columns'
    LoadDXDATA 'View Column Link Graph'
    LoadDXDATA 'Formatting Rules'
    LoadDXDATA 'Integrated Clients'
    LoadDXDATA 'Applets'
    LoadDXDATA 'Models'
    LoadDXDATA 'Literal Groups'
    LoadDXDATA 'Literals'
    LoadDXDATA 'Literal Translations'
    LoadDXDATA 'Data Experience Reference Data'
    LoadDXDATA 'Data Experience Definitions'

    WriteMessage "Step: [$($Steps[$i++])] - Complete"
  }
  # Load REFDATA
  5 {
    WriteMessage ("-" * 100)
    WriteMessage "Step: [$($Steps[$i])] - Installing the $DxdName Reference Data"

    $CsvFiles = Get-ChildItem -Path $(Join-Path $Location "csv") -Name -Filter '*REFDATA*' -Exclude '*Data Sync Configurations*' | Sort-Object
    foreach ($CsvFile in $CsvFiles) {
      LoadREFDATA $CsvFile
    }
            
    WriteMessage "Step: [$($Steps[$i++])] - Complete"
  }
  # Execute Post Install Scripts
  6 {
    WriteMessage ("-" * 100)
    WriteMessage "Step: [$($Steps[$i])] - Executing $DxdName Post Install Scripts"

    if ($CinchyPsPath -ne "") {
      $PsFiles = Get-ChildItem -Path $CinchyPsPath -Name | Sort-Object
      foreach ($PsFile in $PsFiles) {
        WriteMessage "- Executing Script : $PsFile"
        $PsFileCql = Get-Content -Path $(Join-Path $CinchyPsPath $PsFile)
        ExecuteQuery ($PsFileCql -f $DxdGuid) 'NONQUERY' 'JSON' | Out-Null
      }
    }

    WriteMessage "Step: [$($Steps[$i++])] - Complete"
  }
}

LoadDXDATA 'Data Experience Releases'
WriteMessage "$DxdName Data Experience install complete"
