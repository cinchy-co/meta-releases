# ReadMe

This ReadMe contains general information on the components of the Meta-Reports experience. The components should be deployed in the order specified below.


## Components
1) Meta-Forms-App-Experience V1.0.0.zip                     : Angular build files for Meta-Reports UI
2) Meta-Forms-Data-Experience V5.4.0.zip                    : DXD package for Cinchy v5 target environment. Contains the tables and queries that support the Meta-Reports UI


